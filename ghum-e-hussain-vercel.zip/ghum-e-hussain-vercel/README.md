# Ghum E Hussain A.S Website

Standalone React + Vite website, ready for GitHub and Vercel.

## Run on your computer

```bash
npm install
npm run dev
```

## Deploy through GitHub and Vercel

1. Create a new GitHub repository.
2. Upload all files inside this folder to the repository.
3. Go to [vercel.com](https://vercel.com) and choose **Add New Project**.
4. Import the GitHub repository.
5. Keep the default settings:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Output directory: `dist`
6. Click **Deploy**.

## Add a new YouTube video

Open `src/pages/Home.tsx` and add the new video at the top of the `VIDEOS` list:

```ts
{ id: "YOUR_VIDEO_ID", title: "Your video title" },
```

For a link such as `https://www.youtube.com/watch?v=AbCd1234`, the video ID is `AbCd1234`.
Commit and push the change to GitHub. Vercel will automatically redeploy the website.

## Included assets

The channel banner and logo are included in `public/assets/`.