import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { Play, MessageCircle, Menu, X, Globe, Video, Users, Youtube } from 'lucide-react';
import { SiYoutube, SiWhatsapp, SiFacebook, SiTiktok } from 'react-icons/si';

const YOUTUBE_URL = "https://www.youtube.com/@Ghamehussainazadri";
const WHATSAPP_URL = "https://wa.me/923224645281";
const WHATSAPP_NUMBER = "+92 322 4645281";
const TIKTOK_URL = "https://www.tiktok.com/@zawarahsanbuttwrites?is_from_webapp=1&sender_device=pc";

const VIDEOS = [
  { id: "XNBq2qlIevo", title: "Takni Aan Teriyan Rahwan Ghar Aaja Veerna — Safar Ki Pehli Jumerat Noha" },
  { id: "r4y2LmwHl8g", title: "Haye Zainab Veer Di Maut Diyaan — Noha Khwan Party Nawab Karbala | 1 Safar Mukammal Purse" },
  { id: "jYjQJl1oc64", title: "Sajjad Di Akhiyan Wich Dard Aan Di Dastan Ae — Salar Mudassir Shah | Sangat Haram Bibi Pak Daman" },
  { id: "P6ZROq82mjI", title: "Ik Abbas Nu Nau Lakh Ne Mil Kar Mara — 29 Muharram Matam 2026 | Sangat QBH" },
  { id: "UJyWEZTErys", title: "25 Muharram | Ya Hussain Alvida — Sangat Sarkar e Abbas Bawa Tare Shah" },
  { id: "9LwIgkO-KXs", title: "Sham Di Sham Ae Bhenan Nu Nai Bhulni — Qamar Bani Hashim Matam | 26 Muharram 2026" },
];

export default function Home() {
  const { scrollY } = useScroll();
  const opacityHero = useTransform(scrollY, [0, 500], [1, 0]);
  const yHero = useTransform(scrollY, [0, 500], [0, 150]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-primary selection:text-white font-sans overflow-x-hidden">
      
      {/* Sticky Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'glass-nav py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollTo('home')}>
            <img src="/assets/logo.jpeg" alt="Ghum E Hussain Logo" className="h-10 w-10 rounded-full border border-primary/50 object-cover" />
            <span className="font-cinzel font-bold text-lg tracking-wider text-white text-glow-gold hidden sm:block">
              GHUM E HUSSAIN A.S
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {['Videos', 'About', 'Contact'].map((item) => (
              <button 
                key={item} 
                onClick={() => scrollTo(item.toLowerCase())}
                className="text-sm font-medium text-gray-300 hover:text-secondary transition-colors uppercase tracking-widest"
              >
                {item}
              </button>
            ))}
            <a 
              href={YOUTUBE_URL} 
              target="_blank" 
              rel="noreferrer"
              className="px-5 py-2 bg-primary/20 hover:bg-primary/40 border border-primary/50 text-white rounded-full text-sm font-medium transition-all flex items-center gap-2"
            >
              <SiYoutube className="w-4 h-4" /> Subscribe
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-white p-2"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-xl flex flex-col justify-center items-center"
          >
            <button 
              className="absolute top-6 right-6 text-white p-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X className="w-8 h-8" />
            </button>
            
            <img src="/assets/logo.jpeg" alt="Logo" className="w-24 h-24 rounded-full border-2 border-primary mb-12 box-glow-red" />
            
            <div className="flex flex-col gap-8 text-center">
              {['Home', 'Videos', 'About', 'Contact'].map((item) => (
                <button 
                  key={item}
                  onClick={() => scrollTo(item.toLowerCase())}
                  className="font-cinzel text-3xl text-white hover:text-secondary transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative h-[100dvh] flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 z-0">
          <motion.div 
            style={{ y: yHero }}
            className="absolute inset-0 bg-[url('/assets/banner.jpeg')] bg-cover bg-center bg-no-repeat"
          />
          {/* Gradients to darken background */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/40 to-black/90" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent h-32 bottom-0 z-10" />
        </div>

        {/* Content */}
        <motion.div 
          style={{ opacity: opacityHero }}
          className="relative z-10 flex flex-col items-center text-center px-4 max-w-4xl mx-auto mt-20"
        >
          <motion.img 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            src="/assets/logo.jpeg" 
            alt="Logo" 
            className="h-32 w-32 md:h-40 md:w-40 rounded-full border-2 border-primary/50 shadow-[0_0_50px_rgba(139,0,0,0.5)] mb-8 object-cover"
          />
          
          <motion.h1 
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-cinzel text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-4 tracking-wider text-glow-gold"
          >
            GHUM E HUSSAIN A.S
          </motion.h1>
          
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-primary text-lg md:text-2xl font-medium tracking-widest uppercase mb-12"
          >
            Matamdari • Sangat • Majlis • Azadari Videos
          </motion.p>
          
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
          >
            <a 
              href={YOUTUBE_URL} 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center justify-center gap-3 px-8 py-4 bg-primary hover:bg-primary/90 text-white rounded-xl font-bold text-lg transition-all box-glow-red hover:scale-105 active:scale-95"
            >
              <Play className="w-5 h-5 fill-current" />
              Watch on YouTube
            </a>
            <a 
              href={WHATSAPP_URL} 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center justify-center gap-3 px-8 py-4 bg-[#128C7E] hover:bg-[#075E54] text-white rounded-xl font-bold text-lg transition-all shadow-[0_0_20px_rgba(18,140,126,0.3)] hover:scale-105 active:scale-95"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
              Contact on WhatsApp
            </a>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 cursor-pointer text-white/50 hover:text-white transition-colors"
          onClick={() => scrollTo('videos')}
        >
          <span className="text-xs tracking-[0.3em] uppercase">Scroll</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            className="w-px h-12 bg-gradient-to-b from-white/50 to-transparent"
          />
        </motion.div>
      </section>

      {/* Featured Videos Section */}
      <section id="videos" className="py-24 px-6 lg:px-8 bg-[#0a0a0a] relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
        
        <div className="max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="font-cinzel text-4xl md:text-5xl font-bold mb-6 text-glow-gold">Featured Videos</h2>
            <div className="w-24 h-1 bg-secondary mx-auto rounded-full box-glow-gold" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {VIDEOS.map((video, idx) => (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="group glass-card rounded-2xl overflow-hidden hover:border-secondary/50 transition-colors duration-500"
              >
                <div className="relative aspect-video bg-black/50 overflow-hidden">
                  <iframe 
                    className="absolute inset-0 w-full h-full opacity-80 group-hover:opacity-100 transition-opacity duration-500"
                    src={`https://www.youtube.com/embed/${video.id}?rel=0`} 
                    title={video.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen 
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-cinzel font-semibold text-lg mb-4 text-gray-100 group-hover:text-secondary transition-colors line-clamp-2">
                    {video.title}
                  </h3>
                  <a 
                    href={`https://www.youtube.com/watch?v=${video.id}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-medium text-primary group-hover:text-white transition-colors"
                  >
                    Watch Now <Play className="w-4 h-4" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <a 
              href={YOUTUBE_URL} 
              target="_blank" 
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3 rounded-full border border-primary text-primary hover:bg-primary hover:text-white transition-all font-medium uppercase tracking-widest text-sm"
            >
              View Full Channel <Play className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6 lg:px-8 bg-black relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] -translate-y-1/2 -translate-x-1/2" />
        <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
        
        <div className="max-w-7xl mx-auto relative z-10 flex flex-col lg:flex-row items-center gap-16">
          
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="w-full lg:w-1/2 flex justify-center"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-2xl animate-pulse" />
              <div className="absolute -inset-4 border border-primary/30 rounded-full animate-[spin_10s_linear_infinite]" />
              <div className="absolute -inset-8 border border-secondary/20 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
              <img 
                src="/assets/logo.jpeg" 
                alt="About Logo" 
                className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border-4 border-black box-glow-red object-cover z-10"
              />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="w-full lg:w-1/2"
          >
            <h2 className="font-cinzel text-3xl md:text-5xl font-bold mb-6 text-secondary text-glow-gold">
              About Ghum E Hussain A.S
            </h2>
            <p className="text-gray-300 text-lg leading-relaxed mb-8 font-light">
              Ghum E Hussain A.S is dedicated to recording and sharing Matamdari, Sangat, Majlis, and Azadari programs. Our mission is to preserve these sacred moments and make them accessible to viewers around the world through high-quality video recordings. Run with devotion by Azadar Ali Abbas Butt and Zawar Ahsan Butt.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {[
                { icon: <Video />, label: "Azadari Videos" },
                { icon: <Users />, label: "Sangat Programs" },
                { icon: <MessageCircle />, label: "Majlis Recordings" },
                { icon: <Globe />, label: "Worldwide Viewers" }
              ].map((stat, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                    {stat.icon}
                  </div>
                  <span className="font-medium text-sm text-gray-200 uppercase tracking-wider">{stat.label}</span>
                </div>
              ))}
            </div>
          </motion.div>
          
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-6 lg:px-8 bg-[url('/assets/banner.jpeg')] bg-cover bg-fixed bg-center relative">
        <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" />
        
        <div className="max-w-4xl mx-auto relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="glass-card p-10 md:p-16 rounded-3xl text-center relative overflow-hidden"
          >
            {/* Decorative inner glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[300px] bg-primary/20 rounded-full blur-[80px] pointer-events-none" />
            
            <img 
              src="/assets/logo.jpeg" 
              alt="Logo" 
              className="w-24 h-24 rounded-full mx-auto mb-6 border border-primary/50 object-cover relative z-10"
            />
            
            <h2 className="font-cinzel text-3xl md:text-4xl font-bold mb-8 text-white relative z-10">
              Connect With Us
            </h2>
            
            <div className="flex flex-col sm:flex-row justify-center gap-6 mb-10 relative z-10 flex-wrap">
              <a 
                href={YOUTUBE_URL} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-[#FF0000] hover:bg-[#CC0000] text-white rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(255,0,0,0.3)] hover:scale-105"
              >
                <SiYoutube className="w-6 h-6" />
                Visit YouTube Channel
              </a>
              <a 
                href={WHATSAPP_URL} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(37,211,102,0.3)] hover:scale-105"
              >
                <SiWhatsapp className="w-6 h-6" />
                WhatsApp Contact
              </a>
              <a 
                href={TIKTOK_URL} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-black hover:bg-[#111] text-white rounded-xl font-bold transition-all border border-white/20 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:scale-105"
              >
                <SiTiktok className="w-6 h-6" />
                Follow on TikTok
              </a>
            </div>
            
            <div className="inline-block px-6 py-3 rounded-full border border-white/10 bg-white/5 backdrop-blur-sm relative z-10">
              <p className="text-gray-300 font-medium flex items-center gap-2">
                <span className="text-primary">WhatsApp:</span> 
                <span className="text-xl tracking-wider text-white">{WHATSAPP_NUMBER}</span>
              </p>
            </div>
            
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 px-6 border-t border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center gap-6">
          <img 
            src="/assets/logo.jpeg" 
            alt="Logo" 
            className="w-16 h-16 rounded-full border border-white/10 object-cover grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
          />
          
          <div className="flex gap-6 text-gray-500">
            <a href={YOUTUBE_URL} target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">
              <SiYoutube className="w-5 h-5" />
            </a>
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="hover:text-[#25D366] transition-colors">
              <SiWhatsapp className="w-5 h-5" />
            </a>
            <a href={TIKTOK_URL} target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
              <SiTiktok className="w-5 h-5" />
            </a>
            <a href="#" className="hover:text-[#1877F2] transition-colors">
              <SiFacebook className="w-5 h-5" />
            </a>
          </div>

          <div className="text-gray-500 text-sm font-light">
            © 2026 Ghum E Hussain A.S — All Rights Reserved.
          </div>
          
          <div className="font-cinzel text-primary text-sm tracking-[0.3em] font-bold">
            YA HUSSAIN A.S
          </div>
        </div>
      </footer>

    </div>
  );
}
